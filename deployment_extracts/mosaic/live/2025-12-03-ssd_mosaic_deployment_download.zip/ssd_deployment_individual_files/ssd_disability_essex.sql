select
	dis.PERSON_ID disa_person_id,
	null disa_table_id,
	dis.CIN_DISABILITY_CATEGORY_CODE disa_disability_code
from
	SCF.Disabilities dis