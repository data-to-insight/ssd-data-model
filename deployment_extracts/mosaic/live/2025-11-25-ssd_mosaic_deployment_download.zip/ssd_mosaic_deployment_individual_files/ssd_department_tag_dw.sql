-- placeholder file. source data unknown - for ref TeamMosaic

select
	null dept_team_id,          -- [REVIEW]
	null dept_team_name,        -- [REVIEW]
	null dept_team_parent_id,   -- [REVIEW]
	null dept_team_parent_name  -- [REVIEW]

from
	dm_xxxx dept                -- [REVIEW]
